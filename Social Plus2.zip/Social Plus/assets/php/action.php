<?php
require_once 'Function.php';
//for managing signup
if(isset($_GET['signup'])) {
 $response=validateSignupForm($_POST);
if ($response['status']){
 
    if(createUser($_POST)){
        header('location:../../?login');
    }
    else{
        echo "<script>alert('something is worng')</script>";
    }

}
else{
    $_SESSION['error']=$response;
    $_SESSION['formdata']=$_POST;
     header("location:../../?signup");
}
}


//for managing login
if(isset($_GET['login'])) {
   $response=validateLoginForm($_POST);
   if ($response['status']){
    
       $_SESSION['Auth']=true;
       $_SESSION['userdata']=$response['user'];
       header("location:../../");
   
   }
   else{
       $_SESSION['error']=$response;
       $_SESSION['formdata']=$_POST;
        header("location:../../?login");
   }
   }

   if (isset($_GET['updateprofile'])){
    //echo "<pre>";

   // print_r($_FILES);
   $response=validateUpdateForm($_POST,$_FILES['profile_pic']);
  // print_r($response);
    if ($response['status']){
     

       if (updateprofile($_POST,$_FILES['profile_pic'])){
        header("location:../../?editprofile&succcess");
       }else{
        echo "something is wrong";
       }
    
    }
    else{
        $_SESSION['error']=$response;
       // $_SESSION['formdata']=$_POST;
         header("location:../../?editprofile");
    }
   }
//for manaraging add post
if(isset($_GET['addpost'])){
    $response=validatePostImage($_FILES['post_img']);
    if($response['status']){
        if(createPost($_POST,$_FILES['post_img'])){
            header("location:../../?new_post_added");
        }
        else{
            echo "something went wrong";
        }
    }
    else{
        $_SESSION['error']=$response;
        header("location:../../");
    }
}
    
    
    

   

