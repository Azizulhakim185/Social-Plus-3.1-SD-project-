
<?php
require_once'assets/php/Function.php';
//echo "<pre>";
//print_r(getPost());

$user= null;
if(isset($_SESSION['Auth'])) {
   $user= getUser($_SESSION['userdata']['id']);
   $posts = filterPosts();
   $follow_suggestions = filterFollowSuggestion();
}


$pagecount = count($_GET);


//manage pages 
if(isset($_SESSION['Auth'])&& $user['ac_status']==1&& !$pagecount) {
    showPage('header' , ['page_tittle'=>'Home']);
    showpage('navbar');
    showPage('wall');
}
elseif(isset($_SESSION['Auth'])&& isset($_GET['editprofile']) ) {
    showPage('header' , ['page_tittle'=>'Edit Profile']);
    showpage('navbar');
    showPage('edit_profile');
}
elseif(isset($_SESSION['Auth'])&& isset($_GET['u']) && $user['ac_status']==1 ) {
    $profile = getUserByUsername($_GET['u']);
    if(!$profile){
        showPage('header' , ['page_tittle'=>'User Not Found']);
        showpage('navbar');
        showPage('user_not_found');
    }else{
        $profile_post = getPostById($profile['id']); 
        $profile['followers'] = getFollowers($profile['id']);
        $profile['following'] = getFollowing($profile['id']);
        showPage('header' , ['page_tittle'=>$profile['first_name'].' '.$profile['last_name']]);
        showpage('navbar');
        showPage('profile');

    }
   
}



 //for logout the user
 elseif (isset($_GET['logout'])){
   
    session_destroy();
    //header("assets/pages/login.php");
   
    showPage('header' , ['page_tittle'=>'Social Plus - Login']);
    showPage('login');
    
   }   
elseif(isset($_GET['signup'])){

    showPage('header' , ['page_tittle'=>'Social Plus - SignUp']);
    showPage('signup');
   
}
elseif(isset($_GET['login'])){
    showPage('header' , ['page_tittle'=>'Social Plus - Login']);
    showPage('login');
}else{
    if(isset($_SESSION['Auth'])){
    showPage('header' , ['page_tittle'=>'Home']);
    showpage('navbar');
    showPage('wall');
    }
    else{
        showPage('header' , ['page_tittle'=>'Social Plus - Login']);
        showPage('login');
    }
   
}
showPage('Footer'); 
unset($_SESSION['error']);
unset($_SESSION['formdata']);


